import React from 'react';

function Stats() {
  return (
    <div className="stats">
      <h1>Stats</h1>
      {/* Add statistics content here */}
    </div>
  );
}

export default Stats;
