import React from 'react';

function Home() {
  return (
    <div className="home">
      <h1>Welcome to Your Job Application Tracker</h1>
      {/* Add content for the home page */}
    </div>
  );
}

export default Home;
